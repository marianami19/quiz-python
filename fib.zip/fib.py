
proverb1="__1__ and tide wait for no man. \nEvery cloud has a __2__ __3__ . \n__4__ is the best policy. \nLook before you __5__"
answer1=["time","silver","lining","honesty","leap"]
proverb2="__1__ of all trades, master of __2__ .\nFamiliarity breeds __3__.\nThe __4__ is mightier than the sword.\n__5__ favors the bold.\nCleanliness is next to __6__."
answer2=["jack","none","contempt","pen","fortune","godliness"]
proverb3="A picture is worth a __1__ __2__.\n__3__ speak louder than words.\n__4__ can't be choosers.\nBeauty is in the eye of the __5__.\nYou can't judge a __6__ by its cover.\n__7__ is the mother of invention."
answer3=["thousand","words","actions","beggars","beholder","book","necessity"]

#funcfortrial calls function frameforlevel according to the user's input
def funcfortrial():
    response = raw_input("Please enter your name: ")
    print "Hi "+response+"!"
    print "How well do you know your proverbs?\nLets test your proverb skills!\nEnter your level preference :"
    response = raw_input("EASY MEDIUM HARD or ENTER exit to forfeit :")
    if response.lower()=='easy':
        print "LEVEL:EASY\n\n"+proverb1
        frameforlevel(proverb1,answer1)
    elif response.lower()=='medium':
        print "LEVEL:MEDIUM\n\n"+proverb2
        frameforlevel(proverb2,answer2)
    elif response.lower()=='hard':
        print "LEVEL 3:HARD\n\n"+proverb3
        frameforlevel(proverb3,answer3)
    elif response.lower()=='exit':
        print 'BYE!'
    else:
        print "Please enter a valid preference"
#function displaying CONGRATULATIONS if last blank is answered correctly
def congrats_message(count_of_blanks,answer):
    if count_of_blanks==len(answer):
        print "\nCONGRATULATIONS!!!YOU WON."
#If user has used up all his chances then they loose and the function takes the user back to funcfortrial
def defeat_message(chance,guess):
    if chance==guess:
        print "chance",guess
        print "\nYou have lost the Game"
        funcfortrial()
    else:
        print "chance",chance

'''frameforlevel take two parameters--my fill-in-the-blank question and all the answers-to-my-blanks.
If the input answer(blank_answer) is correct then the answer replaces the blank space.
If the is wrong then the user is given chances to guess the answer. The user also gets to decide the number of chances.'''
def frameforlevel(proverb,answer):
        track_of_index=0
        count_of_blanks=1
        while count_of_blanks <= len(answer) :
            blank_answer=raw_input("\nEnter your answer for __"+str(count_of_blanks)+"__")
            if blank_answer.lower()==answer[track_of_index]:
                proverb=proverb.replace("__"+str(count_of_blanks)+"__",blank_answer)
                print "\n"+proverb
                congrats_message(count_of_blanks,answer)
            elif blank_answer.lower()!=answer[track_of_index]:
                guess=input("Wrong Answer\nIn how many guesses can you guess the answer?[enter a valid number please]")
                chance=1
                while chance <= guess:
                    blank_answer=raw_input("Enter your answer for __"+str(count_of_blanks)+"__")
                    if blank_answer.lower()==answer[track_of_index]:
                        proverb=proverb.replace("__"+str(count_of_blanks)+"__",blank_answer)
                        print "\n"+proverb
                        congrats_message(count_of_blanks,answer)
                        break
                    elif blank_answer.lower()!=answer[track_of_index]:
                        defeat_message(chance,guess)
                    chance=chance+1
            count_of_blanks=count_of_blanks+1
            track_of_index=track_of_index+1


funcfortrial()
